# Fergus Barratt
My name is Fergus Barratt and I'm a Physics Masters student at UCL in London. I'm interested in quantum mechanics, quantum optics and mathematical physics.

